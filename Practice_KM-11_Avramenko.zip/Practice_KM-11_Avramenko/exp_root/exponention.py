def exp2(a):
    return a ** 2


def exp3(a):
    return a ** 3
