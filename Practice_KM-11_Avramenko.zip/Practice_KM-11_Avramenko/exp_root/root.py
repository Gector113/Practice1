def root2(a):
    return a ** (1 / 2)


def root3(a):
    return a ** (1 / 3)
