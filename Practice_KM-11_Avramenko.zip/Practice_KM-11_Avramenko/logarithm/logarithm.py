import math


def log(a, b):
    return math.log(b, a)


def ln(a):
    return math.log(a, math.e)


def lg(a):
    return math.log(a, 10)
