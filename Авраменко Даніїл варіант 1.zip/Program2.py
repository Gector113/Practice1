print("Лабораторна робота №6, завдання 2, Авраменко Даніїл КМ-11, варіант 1")
def max_element():
    try:
        n = int(input('Введіть кількість рядків масиву: '))
        m = int(input('Введіть кількість стовпців масиву: '))
        if m > 0 and n > 0:
            a = []
            for i in range(n):
                print('Введіть елементи {} рядка'.format(i + 1))
                a.append([])
                for j in range(m):
                    el = input('Введіть елемент масиву: ')
                    while len(el) == 0 or (not el.isdigit() and not (el[0] == '-' and el[1:].isdigit())):
                        el = input('Введіть елемент масиву ще раз: ')
                    a[i].append(int(el))
            print(a)
            res = []
            m = len(a)
            n = len(a[0])
            for i in range(n):
                c = []
                d = []
                for j in range(m):
                    sum = 0
                    for q in str(a[j][i]):
                        if q != '-':
                            sum = sum + int(q)
                    c.append(sum)
                    d.append(a[j][i])
                res.append(d[c.index(max(c))])
            print(max(res))
        else:
            print('Ви ввели некоректні дані')
    except ValueError:
            print('Ви ввели не число')

def check():
  while True:
        e = input("Бажаєте продовжити ? (yes or no): ")
        if e == "yes":
            max_element()
        elif e == "no":
            print("Програма завершена")
            break
        else:
            print("Потрібно ввести 'yes' або 'no'!")
max_element()
check()