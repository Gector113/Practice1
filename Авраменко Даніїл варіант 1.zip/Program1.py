print("Лабораторна робота №6, завдання 1, Авраменко Даніїл КМ-11, варіант 1")
def replace(a, n = 0):
    if n + 2 > len(a):
        return a
    a[n], a[n + 1] = a[n + 1], a[n]
    replace(a, n + 2)

def check():
    try:
        n = int(input('Введіть кількість елементів масиву: '))
        if n > 0:
            a = []
            for i in range(n):
                el = input('Введіть елемент масиву: ')
                while len(el) == 0 or (not el.isdigit() and not (el[0] == '-' and el[1:].isdigit())):
                    el = input('Введіть елемент масиву ще раз: ')
                a.append(int(el))
            print(a)
            replace(a)
            print(a)
        else:
            print('Ви ввели некоректні дані')
    except ValueError:
        print('Ви ввели некоректні дані')
    
    while True:
        e = input("Бажаєте продовжити ? (yes or no): ")
        if e == "yes":
            check()
        elif e == "no":
            print("Програма завершена")
            break
        else:
            print("Потрібно ввести 'yes' або 'no'!")
check()